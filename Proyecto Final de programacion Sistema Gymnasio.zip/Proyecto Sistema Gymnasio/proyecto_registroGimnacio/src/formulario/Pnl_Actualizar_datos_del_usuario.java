/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formulario;

import SQL.Metodos_SQL;
import java.awt.Component;
import java.awt.Image;
import java.awt.Toolkit;
import java.util.UUID;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 * @author USUARIO
 */
public final class Pnl_Actualizar_datos_del_usuario extends javax.swing.JPanel {

    /**
     * Creates new form Pnl_Actualizar_datos_del_usuario
     */
    public Pnl_Actualizar_datos_del_usuario() {
        initComponents();
        llenar_combo();
        imagen_png_actualizar();
        bloquear();
    }

    Metodos_SQL metodos_SQL = new Metodos_SQL();

    ImageIcon rojo = new ImageIcon(getClass().getResource("/imagenes/check_rojo.png"));
    ImageIcon verde = new ImageIcon(getClass().getResource("/imagenes/check_verde.png"));

    public void llenar_combo() {
        for (int i = 2020; i >= 1869; i--) {
            Combo_añodenacimientoActualizar.addItem(String.valueOf(i));
        }
    }

    public void imagen_gif_actualizar() {
        ImageIcon actualizar_gif;
        actualizar_gif = new ImageIcon(getClass().getResource("/imagenes/actualizar_gif.gif"));
        Icon gif = new ImageIcon(actualizar_gif.getImage().getScaledInstance(120, 120, Image.SCALE_DEFAULT));
        btnGuardarActualizacion.setIcon(gif);

    }

    public void imagen_png_actualizar() {
        ImageIcon actualizar_png;
        actualizar_png = new ImageIcon(getClass().getResource("/imagenes/actualizar_png.png"));
        Icon png = new ImageIcon(actualizar_png.getImage().getScaledInstance(120, 120, Image.SCALE_DEFAULT));
        btnGuardarActualizacion.setIcon(png);
    }

    public void evento_gif() {

        if (!btnGuardarActualizacion.isEnabled()) {
            imagen_png_actualizar();
        } else {
            imagen_gif_actualizar();
        }

    }

    public void contraseña_random() {
        String contraseña = UUID.randomUUID().toString().toUpperCase().substring(0, 10);
        txtContraseñaActualizar.setText(contraseña);

    }

    public void borrar() {
        txtNombreActualizar.setText("");
        txtApellidoActualizar.setText("");
        txtDireccionActualizar.setText("");
        txtContraseñaActualizar.setText("");
        Combo_añodenacimientoActualizar.setSelectedIndex(0);
        bloquear();

    }

    public void buscar_usuario() {
        String dpi = txtDpiActualizaciondeDatos.getText();
        String mensaje = metodos_SQL.buscarDpi(dpi);

        if (mensaje.equals("Existe Dpi")) {
            lblInformacionImagenActualizar.setText("Dpi encontrado se puede modificar datos");
            lblImagenActualizar.setIcon(verde);
            desbloquear();

        } else {
            lblInformacionImagenActualizar.setText("El Dpi no fue encontrado");
            lblImagenActualizar.setIcon(rojo);
            bloquear();
            borrar();
        }

        if (txtDpiActualizaciondeDatos.getText().isEmpty()) {
            lblInformacionImagenActualizar.setText("");
            lblImagenActualizar.setIcon(null);

        }

    }

    public void actualizar_datos() {
        String dpi = txtDpiActualizaciondeDatos.getText();
        String nombre = txtNombreActualizar.getText();
        String apellido = txtApellidoActualizar.getText();
        String direccion = txtDireccionActualizar.getText();
        int año_de_nacimiento = Integer.parseInt((String) Combo_añodenacimientoActualizar.getSelectedItem());
        String contraseña = txtContraseñaActualizar.getText();

        metodos_SQL.actualizar_datos_usuario(nombre, apellido, direccion, contraseña, año_de_nacimiento, dpi);
        borrar();
        borrador_2();

    }

    public void validacion_busqueda_actualizar(java.awt.event.KeyEvent evt) {
        Character c = evt.getKeyChar();

        if (Character.isLetter(c)) {
            evt.setKeyChar(Character.toUpperCase(c));
        }
        if (txtDpiActualizaciondeDatos.getText().length() >= 12) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();

        }

    }

    public void bloquear() {
        for (Component b : Pnl_actualizacion_Datos.getComponents()) {
            b.setEnabled(false);

        }
        for (Component c : Pnl_Opciones_Actualizar.getComponents()) {
            c.setEnabled(false);
        }

    }

    public void desbloquear() {
        for (Component b : Pnl_actualizacion_Datos.getComponents()) {
            b.setEnabled(true);

        }
        for (Component c : Pnl_Opciones_Actualizar.getComponents()) {
            c.setEnabled(true);
        }
        validar_datos();

    }

    public void borrador_2() {
        lblInformacionImagenActualizar.setText("");
        lblImagenActualizar.setIcon(null);
        txtDpiActualizaciondeDatos.setText("");
    }

    public void validar_datos() {
        if (Combo_añodenacimientoActualizar.getSelectedItem().equals("Elegir año de nacimiento") || txtNombreActualizar.getText().isEmpty() || txtApellidoActualizar.getText().isEmpty()
                || txtDireccionActualizar.getText().isEmpty() || txtContraseñaActualizar.getText().isEmpty()) {

            btnGuardarActualizacion.setEnabled(false);

        } else {
            btnGuardarActualizacion.setEnabled(true);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Pnl_actualizacion_Datos = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtContraseñaActualizar = new javax.swing.JTextField();
        Combo_añodenacimientoActualizar = new javax.swing.JComboBox<>();
        txtDireccionActualizar = new javax.swing.JTextField();
        txtApellidoActualizar = new javax.swing.JTextField();
        btncargandoContraseñaActualizar = new javax.swing.JButton();
        lblmostrarContraseñaActualizar = new javax.swing.JLabel();
        txtNombreActualizar = new javax.swing.JTextField();
        Pnl_Opciones_Actualizar = new javax.swing.JPanel();
        btnGuardarActualizacion = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        btnBorradorActualizar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtDpiActualizaciondeDatos = new javax.swing.JTextField();
        lblImagenActualizar = new javax.swing.JLabel();
        lblInformacionImagenActualizar = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        jLabel1.setText("Actualizar Datos del Usuario");

        Pnl_actualizacion_Datos.setBackground(new java.awt.Color(255, 255, 255));
        Pnl_actualizacion_Datos.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Actualizar datos del usuario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 24))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel4.setText("Direccion:");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel5.setText("Año de Nacimiento");

        jLabel6.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel6.setText("Apellido:");

        jLabel12.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel12.setText("contraseña usuario");

        jLabel13.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel13.setText("Nombre:");

        txtContraseñaActualizar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtContraseñaActualizar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtContraseñaActualizarKeyReleased(evt);
            }
        });

        Combo_añodenacimientoActualizar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        Combo_añodenacimientoActualizar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Elegir año de nacimiento" }));
        Combo_añodenacimientoActualizar.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                Combo_añodenacimientoActualizarItemStateChanged(evt);
            }
        });

        txtDireccionActualizar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtDireccionActualizar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDireccionActualizarKeyReleased(evt);
            }
        });

        txtApellidoActualizar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtApellidoActualizar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtApellidoActualizarKeyReleased(evt);
            }
        });

        btncargandoContraseñaActualizar.setBackground(new java.awt.Color(255, 255, 255));
        btncargandoContraseñaActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Random.png"))); // NOI18N
        btncargandoContraseñaActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncargandoContraseñaActualizarActionPerformed(evt);
            }
        });

        lblmostrarContraseñaActualizar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblmostrarContraseñaActualizar.setText("<html><center> Generar contraseña<p> opcional");

        txtNombreActualizar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtNombreActualizar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombreActualizarKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout Pnl_actualizacion_DatosLayout = new javax.swing.GroupLayout(Pnl_actualizacion_Datos);
        Pnl_actualizacion_Datos.setLayout(Pnl_actualizacion_DatosLayout);
        Pnl_actualizacion_DatosLayout.setHorizontalGroup(
            Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pnl_actualizacion_DatosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Combo_añodenacimientoActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtApellidoActualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE)
                    .addComponent(txtDireccionActualizar)
                    .addComponent(txtContraseñaActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreActualizar))
                .addGroup(Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pnl_actualizacion_DatosLayout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(btncargandoContraseñaActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pnl_actualizacion_DatosLayout.createSequentialGroup()
                        .addGap(167, 167, 167)
                        .addComponent(lblmostrarContraseñaActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(106, Short.MAX_VALUE))
        );
        Pnl_actualizacion_DatosLayout.setVerticalGroup(
            Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pnl_actualizacion_DatosLayout.createSequentialGroup()
                .addGroup(Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pnl_actualizacion_DatosLayout.createSequentialGroup()
                        .addGap(123, 123, 123)
                        .addGroup(Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtApellidoActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)
                        .addGroup(Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDireccionActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(Pnl_actualizacion_DatosLayout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNombreActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                        .addComponent(btncargandoContraseñaActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(55, 55, 55)))
                .addGroup(Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Combo_añodenacimientoActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblmostrarContraseñaActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(Pnl_actualizacion_DatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtContraseñaActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(78, 78, 78))
        );

        Pnl_Opciones_Actualizar.setBackground(new java.awt.Color(255, 255, 255));
        Pnl_Opciones_Actualizar.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Opciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 24))); // NOI18N

        btnGuardarActualizacion.setBackground(new java.awt.Color(255, 255, 255));
        btnGuardarActualizacion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/actualizar_gif.gif"))); // NOI18N
        btnGuardarActualizacion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnGuardarActualizacionMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnGuardarActualizacionMouseExited(evt);
            }
        });
        btnGuardarActualizacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActualizacionActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel8.setText("Actualizar");

        btnBorradorActualizar.setBackground(new java.awt.Color(255, 255, 255));
        btnBorradorActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Borrar.png"))); // NOI18N
        btnBorradorActualizar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnBorradorActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorradorActualizarActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel7.setText("Borrar");

        javax.swing.GroupLayout Pnl_Opciones_ActualizarLayout = new javax.swing.GroupLayout(Pnl_Opciones_Actualizar);
        Pnl_Opciones_Actualizar.setLayout(Pnl_Opciones_ActualizarLayout);
        Pnl_Opciones_ActualizarLayout.setHorizontalGroup(
            Pnl_Opciones_ActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pnl_Opciones_ActualizarLayout.createSequentialGroup()
                .addGroup(Pnl_Opciones_ActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pnl_Opciones_ActualizarLayout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pnl_Opciones_ActualizarLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(Pnl_Opciones_ActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnGuardarActualizacion, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBorradorActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(Pnl_Opciones_ActualizarLayout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        Pnl_Opciones_ActualizarLayout.setVerticalGroup(
            Pnl_Opciones_ActualizarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pnl_Opciones_ActualizarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnGuardarActualizacion, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(btnBorradorActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel14.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel14.setText("Ingrese DPI para Actualizar:");

        txtDpiActualizaciondeDatos.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        txtDpiActualizaciondeDatos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDpiActualizaciondeDatosKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDpiActualizaciondeDatosKeyTyped(evt);
            }
        });

        lblInformacionImagenActualizar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 549, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(62, 62, 62)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtDpiActualizaciondeDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 304, Short.MAX_VALUE)
                                .addComponent(lblImagenActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(53, 53, 53)
                                .addComponent(lblInformacionImagenActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 538, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(Pnl_actualizacion_Datos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(45, 45, 45)
                                .addComponent(Pnl_Opciones_Actualizar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jSeparator1))))
                .addContainerGap(127, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblInformacionImagenActualizar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtDpiActualizaciondeDatos, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblImagenActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 9, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Pnl_Opciones_Actualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Pnl_actualizacion_Datos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(177, 177, 177))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 841, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1890, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 94, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 95, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 867, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btncargandoContraseñaActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncargandoContraseñaActualizarActionPerformed
        contraseña_random();
        validar_datos();
    }//GEN-LAST:event_btncargandoContraseñaActualizarActionPerformed

    private void txtDpiActualizaciondeDatosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDpiActualizaciondeDatosKeyReleased
        buscar_usuario();
    }//GEN-LAST:event_txtDpiActualizaciondeDatosKeyReleased

    private void txtDpiActualizaciondeDatosKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDpiActualizaciondeDatosKeyTyped
        validacion_busqueda_actualizar(evt);
    }//GEN-LAST:event_txtDpiActualizaciondeDatosKeyTyped

    private void btnGuardarActualizacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActualizacionActionPerformed
        actualizar_datos();
    }//GEN-LAST:event_btnGuardarActualizacionActionPerformed

    private void btnGuardarActualizacionMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarActualizacionMouseExited
        imagen_png_actualizar();
    }//GEN-LAST:event_btnGuardarActualizacionMouseExited

    private void btnGuardarActualizacionMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarActualizacionMouseEntered
        evento_gif();
    }//GEN-LAST:event_btnGuardarActualizacionMouseEntered

    private void btnBorradorActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorradorActualizarActionPerformed
        borrar();
        borrador_2();

    }//GEN-LAST:event_btnBorradorActualizarActionPerformed

    private void txtNombreActualizarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreActualizarKeyReleased
        validar_datos();
    }//GEN-LAST:event_txtNombreActualizarKeyReleased

    private void txtApellidoActualizarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidoActualizarKeyReleased
        validar_datos();
    }//GEN-LAST:event_txtApellidoActualizarKeyReleased

    private void txtDireccionActualizarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDireccionActualizarKeyReleased
        validar_datos();
    }//GEN-LAST:event_txtDireccionActualizarKeyReleased

    private void txtContraseñaActualizarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtContraseñaActualizarKeyReleased
        validar_datos();
    }//GEN-LAST:event_txtContraseñaActualizarKeyReleased

    private void Combo_añodenacimientoActualizarItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_Combo_añodenacimientoActualizarItemStateChanged
        validar_datos();
    }//GEN-LAST:event_Combo_añodenacimientoActualizarItemStateChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Combo_añodenacimientoActualizar;
    private javax.swing.JPanel Pnl_Opciones_Actualizar;
    private javax.swing.JPanel Pnl_actualizacion_Datos;
    private javax.swing.JButton btnBorradorActualizar;
    private javax.swing.JButton btnGuardarActualizacion;
    private javax.swing.JButton btncargandoContraseñaActualizar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblImagenActualizar;
    private javax.swing.JLabel lblInformacionImagenActualizar;
    private javax.swing.JLabel lblmostrarContraseñaActualizar;
    private javax.swing.JTextField txtApellidoActualizar;
    private javax.swing.JTextField txtContraseñaActualizar;
    private javax.swing.JTextField txtDireccionActualizar;
    private javax.swing.JTextField txtDpiActualizaciondeDatos;
    private javax.swing.JTextField txtNombreActualizar;
    // End of variables declaration//GEN-END:variables
}
