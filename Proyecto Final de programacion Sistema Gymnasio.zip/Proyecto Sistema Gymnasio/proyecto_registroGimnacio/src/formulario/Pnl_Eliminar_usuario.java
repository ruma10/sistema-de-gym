/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package formulario;

import SQL.Conexion_BD;
import SQL.Metodos_SQL;
import java.awt.Component;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public final class Pnl_Eliminar_usuario extends javax.swing.JPanel {

    /**
     * Creates new form Pnl_Eliminar_usuario
     */
    public Pnl_Eliminar_usuario() {
        initComponents();
        imagen_eliminar_png();
        bloquear();
        btnEliminar.setEnabled(true);

    }

    private static Connection conexion;
    private static PreparedStatement sentencia_preparada;
    private static ResultSet resultado;

    ImageIcon rojo = new ImageIcon(getClass().getResource("/imagenes/check_rojo.png"));
    ImageIcon imagen_advertencia = new ImageIcon(getClass().getResource("/imagenes/imagen_advertencia.png"));
    Metodos_SQL metodos_SQL = new Metodos_SQL();

    public void imagen_eliminar_gif() {
        ImageIcon eliminar_gif;
        eliminar_gif = new ImageIcon(getClass().getResource("/imagenes/imagen_eliminar_gif.gif"));
        Icon gif = new ImageIcon(eliminar_gif.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
        btnEliminar.setIcon(gif);

    }

    public void imagen_eliminar_png() {
        ImageIcon eliminar_png;
        eliminar_png = new ImageIcon(getClass().getResource("/imagenes/imagen_eliminar_png.png"));
        Icon png = new ImageIcon(eliminar_png.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT));
        btnEliminar.setIcon(png);
    }

    public void bloquear() {
        for (Component a : Pnl_Eliminacion_deDatosUsuario.getComponents()) {
            a.setEnabled(false);
        }
        for (Component b : Pnl_opciones_Eliminar.getComponents()) {
            b.setEnabled(false);
        }

        imagen_eliminar_png();
    }

    public void desbloquear() {
        for (Component a : Pnl_Eliminacion_deDatosUsuario.getComponents()) {
            a.setEnabled(true);
        }
        for (Component b : Pnl_opciones_Eliminar.getComponents()) {
            b.setEnabled(true);
        }
        imagen_eliminar_gif();
    }

    public void borrar() {
        lblApellidoEliminar.setText("");
        lblAño_de_nacimientoEliminar.setText("");
        lblContraseñaEliminar.setText("");
        lblDireccionEliminar.setText("");
        lblNombreEliminar.setText("");

    }

    public void eliminarBusquedadeUsuario(String dpi) {
        try {
            conexion = Conexion_BD.conectar();
            String sql_busqueda_eliminacion = "SELECT * FROM datos_usuario WHERE dpi = ?";
            sentencia_preparada = conexion.prepareStatement(sql_busqueda_eliminacion);
            sentencia_preparada.setString(1, dpi);
            resultado = sentencia_preparada.executeQuery();
            if (resultado.next()) {
                lblInformacionImagenEliminacion.setText("!ATENCION: Dpi Registrado ");
                lblImagenEliminar.setIcon(imagen_advertencia);
                lblNombreEliminar.setText(resultado.getString("nombre"));
                lblApellidoEliminar.setText(resultado.getString("apellido"));
                lblDireccionEliminar.setText(resultado.getString("direccion"));
                lblContraseñaEliminar.setText(resultado.getString("contraseña"));
                lblAño_de_nacimientoEliminar.setText(resultado.getString("año_de_nacimiento"));
                desbloquear();

            } else {
                lblInformacionImagenEliminacion.setText("no se obtuvieron resultado en la busqueda");
                lblImagenEliminar.setIcon(rojo);
                bloquear();
                borrar();

            }

            conexion.close();

        } catch (SQLException e) {
            System.out.println("Error" + e);
        } finally {

            try {
                conexion.close();
            } catch (SQLException ex) {
                Logger.getLogger(Pnl_Eliminar_usuario.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println("Error" + ex);
            }

        }
        borrarCaja();

    }

    public void borrarCaja() {
        if (txtDpiBuscarEliminar.getText().isEmpty()) {
            lblImagenEliminar.setIcon(null);
            lblInformacionImagenEliminacion.setText("");
            borrar();
        }
    }

    public void clausula_caja_texto(java.awt.event.KeyEvent evt) {
        Character a = evt.getKeyChar();

        if (Character.isLetter(a)) {
            evt.setKeyChar(Character.toUpperCase(a));

        }

        if (txtDpiBuscarEliminar.getText().length() >= 12) {
            evt.consume();
            Toolkit.getDefaultToolkit().beep();

        }

    }

    public void eliminar_usuarioPreguntas() {

        int pregunta;
        pregunta = JOptionPane.showConfirmDialog(null, "esta seguro de querer eliminar el usuario", "Confirmar Borrado", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (pregunta == 0) {
            metodos_SQL.eliminar_usuario(txtDpiBuscarEliminar.getText());
            txtDpiBuscarEliminar.setText("");
            borrar();
            borrarCaja();
            bloquear();

        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Pnl_Eliminacion_deDatosUsuario = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        lblDireccionEliminar = new javax.swing.JLabel();
        lblAño_de_nacimientoEliminar = new javax.swing.JLabel();
        lblContraseñaEliminar = new javax.swing.JLabel();
        lblApellidoEliminar = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        lblNombreEliminar = new javax.swing.JLabel();
        Pnl_opciones_Eliminar = new javax.swing.JPanel();
        btnEliminar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtDpiBuscarEliminar = new javax.swing.JTextField();
        lblImagenEliminar = new javax.swing.JLabel();
        lblInformacionImagenEliminacion = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        jLabel1.setText("Eliminar Usuario");

        Pnl_Eliminacion_deDatosUsuario.setBackground(new java.awt.Color(255, 255, 255));
        Pnl_Eliminacion_deDatosUsuario.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos del Usuario", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 24))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel4.setText("Direccion:");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel5.setText("Año de Nacimiento");

        jLabel6.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel6.setText("Apellido:");

        jLabel12.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel12.setText("contraseña usuario");

        lblDireccionEliminar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N

        lblAño_de_nacimientoEliminar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N

        lblContraseñaEliminar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N

        lblApellidoEliminar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N

        jLabel17.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel17.setText("Nombre:");

        lblNombreEliminar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N

        javax.swing.GroupLayout Pnl_Eliminacion_deDatosUsuarioLayout = new javax.swing.GroupLayout(Pnl_Eliminacion_deDatosUsuario);
        Pnl_Eliminacion_deDatosUsuario.setLayout(Pnl_Eliminacion_deDatosUsuarioLayout);
        Pnl_Eliminacion_deDatosUsuarioLayout.setHorizontalGroup(
            Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createSequentialGroup()
                .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createSequentialGroup()
                        .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lblApellidoEliminar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 259, Short.MAX_VALUE)
                            .addComponent(lblDireccionEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblNombreEliminar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(lblContraseñaEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblAño_de_nacimientoEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(96, Short.MAX_VALUE))
        );
        Pnl_Eliminacion_deDatosUsuarioLayout.setVerticalGroup(
            Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createSequentialGroup()
                .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNombreEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblApellidoEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createSequentialGroup()
                        .addGap(170, 170, 170)
                        .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblContraseñaEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(30, 30, 30)
                .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDireccionEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 79, Short.MAX_VALUE)
                .addGroup(Pnl_Eliminacion_deDatosUsuarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAño_de_nacimientoEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(114, 114, 114))
        );

        Pnl_opciones_Eliminar.setBackground(new java.awt.Color(255, 255, 255));
        Pnl_opciones_Eliminar.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Opciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 24))); // NOI18N

        btnEliminar.setBackground(new java.awt.Color(255, 255, 255));
        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/imagen_Eliminar_png.png"))); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel8.setText("Eliminar Usuario");

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Borrar.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel9.setText("Borrar");

        javax.swing.GroupLayout Pnl_opciones_EliminarLayout = new javax.swing.GroupLayout(Pnl_opciones_Eliminar);
        Pnl_opciones_Eliminar.setLayout(Pnl_opciones_EliminarLayout);
        Pnl_opciones_EliminarLayout.setHorizontalGroup(
            Pnl_opciones_EliminarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pnl_opciones_EliminarLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(Pnl_opciones_EliminarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Pnl_opciones_EliminarLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(66, Short.MAX_VALUE))
        );
        Pnl_opciones_EliminarLayout.setVerticalGroup(
            Pnl_opciones_EliminarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pnl_opciones_EliminarLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel13.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel13.setText("Ingrese el DPI para eliminar datos:");

        txtDpiBuscarEliminar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        txtDpiBuscarEliminar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDpiBuscarEliminarKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDpiBuscarEliminarKeyTyped(evt);
            }
        });

        lblImagenEliminar.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N

        lblInformacionImagenEliminacion.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(68, 68, 68)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 381, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtDpiBuscarEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblImagenEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(lblInformacionImagenEliminacion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(Pnl_Eliminacion_deDatosUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(81, 81, 81)
                                .addComponent(Pnl_opciones_Eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jSeparator1))))
                .addGap(96, 96, 96))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDpiBuscarEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblImagenEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblInformacionImagenEliminacion, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Pnl_opciones_Eliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Pnl_Eliminacion_deDatosUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(48, 48, 48))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1516, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 778, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void txtDpiBuscarEliminarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDpiBuscarEliminarKeyReleased
        eliminarBusquedadeUsuario(txtDpiBuscarEliminar.getText());
    }//GEN-LAST:event_txtDpiBuscarEliminarKeyReleased

    private void txtDpiBuscarEliminarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDpiBuscarEliminarKeyTyped
        clausula_caja_texto(evt);
    }//GEN-LAST:event_txtDpiBuscarEliminarKeyTyped

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        eliminar_usuarioPreguntas();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        txtDpiBuscarEliminar.setText("");
        borrar();
        borrarCaja();
        bloquear();
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Pnl_Eliminacion_deDatosUsuario;
    private javax.swing.JPanel Pnl_opciones_Eliminar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblApellidoEliminar;
    private javax.swing.JLabel lblAño_de_nacimientoEliminar;
    private javax.swing.JLabel lblContraseñaEliminar;
    private javax.swing.JLabel lblDireccionEliminar;
    private javax.swing.JLabel lblImagenEliminar;
    private javax.swing.JLabel lblInformacionImagenEliminacion;
    private javax.swing.JLabel lblNombreEliminar;
    public javax.swing.JTextField txtDpiBuscarEliminar;
    // End of variables declaration//GEN-END:variables
}
