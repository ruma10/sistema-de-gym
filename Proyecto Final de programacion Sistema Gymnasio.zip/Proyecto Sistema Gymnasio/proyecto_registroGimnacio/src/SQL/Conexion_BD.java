package SQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion_BD {

    static String URL = "jdbc:mysql://localhost/bd_sistema_gym";
    static String usuario = "root";
    static String contraseña = "Perez.rum";

    public static Connection conectar() {
        Connection conexion = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            conexion = DriverManager.getConnection(URL, usuario, contraseña);
            System.out.println("Conexion establecida");

        } catch (ClassNotFoundException | SQLException e) {

            System.out.println("Error: " + e);
        }

        return conexion;

    }

}
