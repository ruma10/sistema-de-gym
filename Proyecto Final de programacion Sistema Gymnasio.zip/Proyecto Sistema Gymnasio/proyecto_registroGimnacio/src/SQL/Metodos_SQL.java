package SQL;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Metodos_SQL {

    private static Connection conexion;
    private static PreparedStatement sentencia_preparada;
    private static ResultSet resultado;

    public void guardar_datos_usuario(String dpi, String nombre, String apellido, String direccion, int año_de_nacimiento, String contraseña) {

        try {

            conexion = Conexion_BD.conectar();
            String consulta = "INSERT INTO datos_usuario(dpi,nombre,apellido,direccion,año_de_nacimiento,contraseña) VALUE (?,?,?,?,?,?)";
            sentencia_preparada = conexion.prepareStatement(consulta);
            sentencia_preparada.setString(1, dpi);
            sentencia_preparada.setString(2, nombre);
            sentencia_preparada.setString(3, apellido);
            sentencia_preparada.setString(4, direccion);
            sentencia_preparada.setInt(5, año_de_nacimiento);
            sentencia_preparada.setString(6, contraseña);
            int i = sentencia_preparada.executeUpdate();

            if (i > 0) {
                JOptionPane.showMessageDialog(null, "Datos guardados");

            } else {
                JOptionPane.showMessageDialog(null, "Error al guardar datos");
            }

            conexion.close();

        } catch (HeadlessException | SQLException e) {

            System.out.println("Error: " + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error: " + e);
            }

        }

    }

    public static String buscarDpi(String dpi) {
        String mensaje = null;

        try {
            conexion = Conexion_BD.conectar();
            String consulta = "SELECT dpi FROM datos_usuario WHERE dpi = ?";
            sentencia_preparada = conexion.prepareStatement(consulta);
            sentencia_preparada.setString(1, dpi);
            resultado = sentencia_preparada.executeQuery();

            if (resultado.next()) {
                mensaje = "Existe Dpi";

            } else {
                mensaje = "No Existe Dpi";

            }

        } catch (SQLException e) {
            System.out.println("Error: " + e);

        } finally {
            try {
                conexion.close();
            } catch (SQLException ex) {
                Logger.getLogger(Metodos_SQL.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return mensaje;
    }

    public void actualizar_datos_usuario(String nombre, String apellido, String direccion, String contraseña, int año_de_nacimiento, String dpi) {

        try {
            conexion = Conexion_BD.conectar();
            String consulta = "UPDATE datos_usuario SET nombre = ?, apellido = ?, direccion = ?, contraseña = ?, año_de_nacimiento = ? WHERE dpi = ?";
            sentencia_preparada = conexion.prepareStatement(consulta);
            sentencia_preparada.setString(1, nombre);
            sentencia_preparada.setString(2, apellido);
            sentencia_preparada.setString(3, direccion);
            sentencia_preparada.setString(4, contraseña);
            sentencia_preparada.setInt(5, año_de_nacimiento);
            sentencia_preparada.setString(6, dpi);

            int i = sentencia_preparada.executeUpdate();

            if (i < 0) {
                JOptionPane.showMessageDialog(null, "No se actualizaron los Datos");

            } else {
                JOptionPane.showMessageDialog(null, "Datos actualizados");
            }
            conexion.close();

        } catch (HeadlessException | SQLException e) {
            System.out.println("Erro" + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error" + e);
            }
        }
    }

    public void eliminar_usuario(String dpi) {
        try {
            conexion = Conexion_BD.conectar();
            String consulta_eliminacion = "DELETE FROM datos_usuario WHERE dpi = ?";
            sentencia_preparada = conexion.prepareStatement(consulta_eliminacion);
            sentencia_preparada.setString(1, dpi);
            sentencia_preparada.executeUpdate();
            int resultado_fila_afectada = sentencia_preparada.executeUpdate();
            if (resultado_fila_afectada > 0) {
                JOptionPane.showMessageDialog(null, "No se pudo eliminar el Usuario");
            } else {
                JOptionPane.showMessageDialog(null, "Usuario eliminado correctamente");
            }

            conexion.close();

        } catch (HeadlessException | SQLException e) {
            System.out.println("Error" + e);
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                System.out.println("Error" + e);
            }
        }
    }

}
