
package proyecto_registrogimnacio;

import formulario.frm_Menu_principal;


public class Proyecto_registroGimnacio {

   
    public static void main(String[] args) {
        frm_Menu_principal.main(args);
        
    }
    
}
